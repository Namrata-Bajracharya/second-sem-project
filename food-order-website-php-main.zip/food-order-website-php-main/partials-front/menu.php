<?php include('config/constants.php'); ?>

 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


    <title>Menu</title>
     <!-- Link our CSS file -->
 <link rel="stylesheet" href="css/style.css">
    <style>
      body{
    margin: 0;
    font-family: Poppins;
}
.container{
    width: 900px;
    margin: auto;
    max-width: 90vw;
    text-align: center;
    padding-top: 10px;
    transition: transform .5s;
}
svg{
    width: 30px;
    color:white
}
header{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 0;
}
.icon-cart{
    position: relative;
}
.icon-cart span{
    position: absolute;
    background-color: red;
    width: 30px;
    height: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    color: #fff;
    top: 50%;
    right: -20px;
}
.title{
    font-size: xx-large;
}
.listProduct .item img{
    width: 90%;
    filter: drop-shadow(0 50px 20px #0009);
}
.listProduct{
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}
.listProduct .item{
    background-color: #EEEEE6;
    padding: 20px;
    border-radius: 20px;
}
.listProduct .item h2{
    font-weight: 500;
    font-size: large;
}
.listProduct .item .price{
    letter-spacing: 7px;
    font-size: small;
}
.listProduct .item button{
    background-color: #353432;
    color: #eee;
    border: none;
    padding: 5px 10px;
    margin-top: 10px;
    border-radius: 20px;
}

/* cart */
/* .cartTab{
    width: 400px;
    background-color: #353432;
    color: #eee;
    position: fixed;
    top: 0;
    right: -400px;
    bottom: 0;
    display: grid;
    grid-template-rows: 70px 1fr 70px;
    transition: .5s;
}
body.showCart .cartTab{
    right: 0;
}
body.showCart .container{
    transform: translateX(-250px);
}
.cartTab h1{
    padding: 20px;
    margin: 0;
    font-weight: 300;
}
.cartTab .btn{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
}
.cartTab button{
    background-color: #E8BC0E;
    border: none;
    font-family: Poppins;
    font-weight: 500;
    cursor: pointer;
}
.cartTab .close{
    background-color: #eee;
} */
.cartTab {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.cartTab a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.cartTab a:hover {
  color: #f1f1f1;
}
.cartTab h1{
    padding: 20px;
    margin: 0;
    font-weight: 300;
}
.cartTab .btn{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
}
.cartTab button{
    background-color: #E8BC0E;
    border: none;
    font-family: Poppins;
    font-weight: 500;
    cursor: pointer;
}
.cartTab .close{
    background-color: #eee;
}
.cartTab .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}
.listCart .item img{
    width: 100%;
}
.listCart .item{
    display: grid;
    grid-template-columns: 70px 150px 50px 1fr;
    gap: 10px;
    text-align: center;
    align-items: center;
}
.listCart .quantity span{
    display: inline-block;
    width: 25px;
    height: 25px;
    background-color: #eee;
    border-radius: 50%;
    color: #555;
    cursor: pointer;
}
.listCart .quantity span:nth-child(2){
    background-color: transparent;
    color: #eee;
    cursor: auto;
}
.listCart .item:nth-child(even){
    background-color: #eee1;
}
.listCart{
    overflow: auto
}
.listCart::-webkit-scrollbar{
    width: 0;
}
@media only screen and (max-width: 992px) {
    .listProduct{
        grid-template-columns: repeat(3, 1fr);
    }
}


/* mobile */
@media only screen and (max-width: 768px) {
    .listProduct{
        grid-template-columns: repeat(2, 1fr);
    }
}
    </style>
  </head>
  <body>
  

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark color-light">
        <div class="container">
          <a class="navbar-brand" href="#">brunch</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse d-flex justify-content-evenly" id="navbarNavDropdown">
            <ul class="navbar-nav ">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="<?php echo SITEURL; ?>">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo SITEURL; ?>categories.php">Categories</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo SITEURL; ?>foods.php">Foods</a>
              </li>
              
            </ul>
          </div>
          <div>
                        
            <div class="icon-cart" onclick="openNav()">
                <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 15a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm0 0h8m-8 0-1-4m9 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm-9-4h10l2-7H3m2 7L3 4m0 0-.792-3H1"/>
                </svg>
                <span id="output">0</span>
            </div>
            
          </div>
        </div>
      </nav>

  </div>
  <div class="cartTab sidenav" id="mySidenav">
      <h1>Shopping Cart</h1>
      <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
      <div class="listCart">
        
      
      </div>
      <div class="btn">
          <button class="close">CLOSE</button>
          <button class="checkOut">Check Out</button>
      </div>
  </div>
  <script src="app.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script>
        function openNav() {
        document.getElementById("mySidenav").style.width = "500px";
        document.getElementById("main").style.marginLeft = "500px";
        }

        function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        }
</script>

</body>
</html>